Mai The Tam - SE205068 - LOS201
Assignment 02

This archive is bootable without the full GitHub checkout.
Run: bash scripts/run-qemu.sh
Press Enter to activate the guest console.
Then run: test_arm.sh
For an interactive run after the test: sms_app -d 0 -v
Press Ctrl+C to stop cleanly.
Video and personal reflection were omitted at the student's request.

To rebuild drivers, set KDIR to a built Linux 5.15 ARM tree using kernel/kernel.config.
The full repository includes source/image build scripts and the report generator:
https://github.com/KamiMai/LOS201
The kernel source archive and toolchain are external build dependencies.
HOST profiling uses an explicitly selected simulator; see the report for limitations.
