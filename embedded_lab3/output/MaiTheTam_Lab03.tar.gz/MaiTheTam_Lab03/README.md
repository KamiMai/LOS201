# LAB03 Debugging and performance analysis

Target: Linux 5.15.0, ARMv7 Cortex-A9, QEMU vexpress-a9. Host: Ubuntu x86-64.

This lab adds remote application debugging with GDB, memory analysis with Valgrind, syscall and CPU profiling, and host scheduling latency measurements.

## Progress

- [x] Record the initial host environment.
- [x] Prepare ARM tools and boot the debugging rootfs.
- [x] Capture remote GDB evidence for three application bugs.
- [x] Capture Valgrind results before and after fixes.
- [x] Observe ARM process memory while the process is alive.
- [x] Collect host and ARM strace results and host perf profiles.
- [x] Measure host latency at idle and under load and plot histograms.
- [x] Complete the report and submission archive.

The real-time section follows D.5: measurements use the current host kernel; PREEMPT_RT is compared theoretically. No RT kernel installation or reboot is required. Recorded maxima are observed results, not guaranteed worst-case bounds.

## Layout

`apps/` holds original and fixed sources and binaries; `scripts/` holds reproducible commands; `logs/` holds actual tool output; `output/` holds the bootable initramfs; `report/` holds the final report.

Device nodes, pseudo-filesystems and downloaded build trees are not tracked. Build outputs required by the assignment are retained. Original LAB01 and LAB02 files are unchanged.

## ARM rootfs

`gdbserver` 15.1 and `strace` 6.8 are Ubuntu armhf packages, downloaded from ports.ubuntu.com. The libc, loader, libstdc++ and libgcc runtime files come from `/usr/arm-linux-gnueabihf/lib`. Applications are linked statically for this lab.

Build the initial app with `make -C embedded_lab3/apps buggy_app`, pack with `bash embedded_lab3/scripts/pack.sh`, then boot with `bash embedded_lab3/scripts/run-qemu.sh`. The packer uses the LAB01 kernel's `usr/gen_init_cpio` helper to create console device nodes without root privileges.

The guest receives 10.0.2.15 through DHCP. Host localhost TCP 1234 is forwarded to guest TCP 1234. Run `gdbserver 0.0.0.0:1234 /usr/bin/buggy_app` in the guest and connect using `gdb-multiarch embedded_lab3/apps/buggy_app` on the host.

Logs retain boot warnings from the inherited kernel; successful module loading, DHCP and application/tool execution must be checked separately.

The minimal rootfs lacks resolver configuration; bind gdbserver explicitly to `0.0.0.0:1234`. The shorthand `:1234` failed name resolution in this image.

## GDB results

Run `bash embedded_lab3/scripts/debug.sh` after starting gdbserver in the guest. The command file captures an out-of-bounds access (`i == len == 5`), a software watchpoint, the same buffer address before/after free, and signed integer overflow. The observed 32-bit product was 1410065408 instead of 10000000000. This buggy run exited normally: absence of a crash does not imply memory safety. Full commands and values are in `logs/gdb_session.txt`.

## Valgrind baseline

The original `leaky_app.c` is unchanged from the assignment. Memcheck reported 16900 bytes definitely lost in 250 blocks: 2100 bytes of names, 2000 bytes of scores and 12800 bytes of message buffers. Indirectly lost was zero. The intentional failing run returned the configured exit code 99. See `logs/valgrind_report.txt`, `logs/valgrind_run.txt` and `logs/leaky_app_output.txt`.

## Memory fixes and ARM observation

The fixed program frees `name` and `scores` before freeing each record, releases message buffers after use, and cleans up partial allocation failures. Memcheck recorded 352 allocations, 352 frees, zero bytes at exit and zero errors.

`memory_observe_arm leaky|fixed` repeats the assignment workload with explicit 5-second and 8-second observation windows. Run `/usr/bin/observe_memory.sh` in QEMU. In this small-workload run, both modes showed VmSize=624 kB, VmRSS=4 kB and VmData=152 kB before and after. These coarse process counters did not expose the 16900-byte leak; Memcheck is the direct evidence. Freeing memory need not return its arena to the OS. See `logs/arm_memory.txt`.

## Profiling results

The measured workload keeps the original math function, consumes search results and varies each query to prevent loop-invariant hoisting. An optional integer argument selects 1-10000 compute iterations; default is 50. `perf_target_original.c` retains the assignment version.

Use `bash embedded_lab3/scripts/profile-host.sh` for host timing/strace and `sudo bash embedded_lab3/scripts/measure-host.sh` for perf and scheduling latency. Perf uses 2000 compute iterations and samples `cycles:u` at 997 Hz; timing/strace and ARM comparison use 50 iterations. Do not compare the two iteration counts as equal workloads.

Final record/report/script/stat completed successfully on perf 7.0.14. The dominant symbols are libm log and heavy_compute, with linear_search now also sampled. The earlier apparent perf failures were target-program crashes: unchecked fopen of a shared /tmp filename failed under sudo with fs.protected_regular=2. The measured program now uses mkstemp and checks I/O. Original failure transcripts are retained.

Rootfs includes memory and profiling apps. The ARM program was checked after the final source change; checksum is 99991021. Gnuplot and FlameGraph outputs are based on the saved raw captures; FlameGraph's upstream commit is recorded.

## Host latency

The final runs used 4 FIFO threads at priority 80, CPU affinity 0-3, interval 1000 us, mlockall, 60 seconds per run and 10000 histogram bins. QEMU and the temporary HTTP server were stopped before these runs. The loaded run used stress-ng cpu=8/io=2/vm=2 with 256M VM bytes and a 5-second warm-up. Desktop/background services remained active.

| Run | Min us | Weighted Avg us | Observed Max us | P99 us | Samples | Overflow |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| idle | 2 | 4.36 | 2982 | 19 | 239996 | 0 |
| loaded | 3 | 8.88 | 863 | 45 | 240000 | 0 |

These are observations, not guaranteed upper bounds. Loaded mean/P99 increased, while the observed maximum was lower than the baseline maximum; rare events and finite sampling matter. PREEMPT_RT was not installed or measured. `scripts/analyze-latency.py` and `scripts/plot-latency.gnuplot` reproduce the JSON summary and plot. Run gnuplot from embedded_lab3/.

## Report and submission

The 11-page Vietnamese report is `report/LAB03_BaoCao.pdf`; its generator reads the saved logs. Rebuild with Python 3 plus reportlab after generating `logs/latency_summary.json` and the gnuplot image. DejaVu Sans/Mono fonts are required.

Run `python3 embedded_lab3/scripts/package.py` to create `output/MaiTheTam_Lab03.tar.gz` and its SHA-256 sidecar. The archive includes apps, configs, scripts, actual logs, the initramfs and the PDF under bao_cao/. It does not duplicate the LAB01 kernel. After extracting, run scripts/run-qemu.sh with LAB1_OUTPUT set to a directory containing zImage and vexpress-v2p-ca9.dtb; the original ~/embedded_lab1/output is also detected.

MSSV and class/group were not supplied. Fill those fields in the report source, rebuild the PDF and archive, and rename the submission using the required MSSV_HoTen convention before handing it in. PREEMPT_RT remains a theoretical comparison as allowed by D.5.

Final checks are recorded in logs/final_validation.txt. The packaged image was booted again: the fixed memory app and profiling app returned zero, DHCP/module loading worked, and the ARM binary checksum matched the host build.
