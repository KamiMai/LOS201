#!/bin/bash
set -euo pipefail
lab=$(cd "$(dirname "$0")/.." && pwd)
exec qemu-system-arm -M vexpress-a9 -cpu cortex-a9 -m 512M -smp 2 -nographic \
 -kernel "$lab/kernel/zImage" -dtb "$lab/kernel/vexpress-v2p-ca9.dtb" \
 -initrd "$lab/output/initramfs_asgn1.cpio.gz" \
 -append 'console=ttyAMA0,115200 rdinit=/sbin/init mem=512M'
