Mai The Tam - SE205068 - LOS201
Assignment 01

This archive is bootable without the full GitHub checkout.
Run: bash scripts/run-qemu.sh
Press Enter to activate the guest console.
Then run:
/opt/asgn1/task1_ioctl/test_asgn1.sh
/opt/asgn1/task2_misc/test_counter.sh

To rebuild drivers, set KDIR to a built Linux 5.15 ARM tree using kernel/kernel.config.
The full repository includes source/image build scripts and the report generator:
https://github.com/KamiMai/LOS201
The kernel source archive and toolchain are external build dependencies.
HOST profiling uses an explicitly selected simulator; see the report for limitations.
